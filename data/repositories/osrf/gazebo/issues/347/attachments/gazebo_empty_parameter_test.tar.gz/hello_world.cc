/*
 * Copyright 2011 Nate Koenig & Andrew Howard
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
*/
#include <gazebo/gazebo.hh>

namespace gazebo
{
  class WorldPluginTutorial : public WorldPlugin
  {
    private:
            std::string text;

    public: WorldPluginTutorial() : WorldPlugin()
            {
            }

    public: void Load(physics::WorldPtr _world, sdf::ElementPtr _sdf)
            {

              // This code will segfault if the parameter tag exists but has no text
              if (_sdf->HasElement("text")) text = _sdf->GetElement("text")->GetValueString();

              // This one works, but it is cumbersome to always have to check the value pointer...
              if (_sdf->HasElement("text") && _sdf->GetElement("text")->GetValue()) text = _sdf->GetElement("text")->GetValueString();

              if (text.empty()) {
                std::cout << "Plugin parameter was empty, using default value!" << std::endl;
                text = "Hello world!";
              }

              std::cout << text << std::endl;
            }
  };
  GZ_REGISTER_WORLD_PLUGIN(WorldPluginTutorial)
}
