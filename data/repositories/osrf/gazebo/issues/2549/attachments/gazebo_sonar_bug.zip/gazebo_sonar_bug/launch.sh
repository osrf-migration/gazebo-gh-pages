#!/bin/bash

source /usr/share/gazebo/setup.sh

GAZEBO_MODEL_PATH=.:$GAZEBO_MODEL_PATH
GAZEBO_PLUGIN_PATH=.:$GAZEBO_PLUGIN_PATH

gazebo --verbose test.world

