
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <gazebo/sensors/CameraSensor.hh>
#include <gazebo/sensors/ImuSensor.hh>
#include <gazebo/sensors/SonarSensor.hh>
#include <gazebo/sensors/SensorManager.hh>

#include <ignition/math.hh>

//	gazebo interface updates
#if GAZEBO_MAJOR_VERSION < 7
#define GAZEBO_SENSOR_TYPE GetType
#define GAZEBO_SENSOR_UPDATE_RATE GetUpdateRate
#define GAZEBO_CAMERA_SENSOR_IMAGE_WIDTH GetImageWidth
#define GAZEBO_CAMERA_SENSOR_IMAGE_HEIGHT GetImageHeight
#define GAZEBO_CAMERA_SENSOR_IMAGE_DATA GetImageData
#define GAZEBO_IMU_SENSOR_LINEAR_ACCELERATION GetLinearAcceleration
#define GAZEBO_SONAR_SENSOR_RANGE GetRange
#define GAZEBO_SCOPED_NAME GetScopedName
#else
#define GAZEBO_SENSOR_TYPE Type
#define GAZEBO_SENSOR_UPDATE_RATE UpdateRate
#define GAZEBO_CAMERA_SENSOR_IMAGE_WIDTH ImageWidth
#define GAZEBO_CAMERA_SENSOR_IMAGE_HEIGHT ImageHeight
#define GAZEBO_CAMERA_SENSOR_IMAGE_DATA ImageData
#define GAZEBO_IMU_SENSOR_LINEAR_ACCELERATION LinearAcceleration
#define GAZEBO_SONAR_SENSOR_RANGE Range
#define GAZEBO_SCOPED_NAME ScopedName
#endif

//	gazebo interface updates
#if GAZEBO_MAJOR_VERSION < 8
#define GAZEBO_GET_SIM_TIME GetSimTime
#else
#define GAZEBO_GET_SIM_TIME SimTime
#endif

#include <stdio.h>
#include <string>
using namespace std;

#define __ERROR(msg) do { \
	cout << "**** ERROR **** " << msg << endl; \
	throw "stop"; \
} while(false)

namespace gazebo
{
	struct MY_ModelPlugin : public ModelPlugin
	{
		MY_ModelPlugin()
			:
			ModelPlugin()
		{
		}

		~MY_ModelPlugin()
		{
		}

		sensors::SensorPtr GetSensor(string name, string expected_type)
		{
			//	search by scoped name
			name = "default::" + this->model->GetScopedName() + "::main_link::" + name;
			sensors::Sensor_V sensors =
				sensors::SensorManager::Instance()->GetSensors();
			sensors::SensorPtr sensor = NULL;
			for (size_t i=0; i<sensors.size(); i++)
			{
				string sname = sensors[i]->GAZEBO_SCOPED_NAME();
				if (sname.find(name) != string::npos)
				{
					sensor = sensors[i];
					break;
				}
			}

            if (!sensor)
            {
            	string e = "could not retrieve sensor \"";
            	e += name;
            	e += "\" (see above for sensor list)";
				return NULL;
            }

            if (sensor->GAZEBO_SENSOR_TYPE() != expected_type)
			{
            	string e = "sensor \"";
            	e += name;
            	e += "\" was not of expected type \"";
            	e += expected_type;
            	e += "\"";
				__ERROR(e.c_str());
			}

			cout << "retrieved sensor \"" << sensor->GAZEBO_SCOPED_NAME()
				<< "\" of type \"" << expected_type << "\" "
				<< (sensor->IsActive() ? "(active, " : "(inactive, ")
				<< sensor->GAZEBO_SENSOR_UPDATE_RATE()
				<< ")"
				<< endl;

            return sensor;
		}

		void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/)
		{
			cout << "Load()" << endl;

			//	get pointer to model
			this->model = _parent;

			//	get sensor
			sensors::SensorPtr sensor = GetSensor("sonar1", "sonar");

			//	if present
			if (sensor)
			{
				//	remove sensor
				sensors::SensorManager::Instance()->RemoveSensor(sensor->GAZEBO_SCOPED_NAME());
			}
		}

	private:

		physics::ModelPtr model;
	};

	GZ_REGISTER_MODEL_PLUGIN(MY_ModelPlugin)
}




