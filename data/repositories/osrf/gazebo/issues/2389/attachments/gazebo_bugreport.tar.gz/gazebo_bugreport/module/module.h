#pragma once

#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>

namespace gazebo {
  class POCModule : public ModelPlugin {
    public:
      void Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/);
  
      void OnUpdate(const common::UpdateInfo & /*_info*/);

    private:
      event::ConnectionPtr updateConnection;
      physics::WorldPtr mWorld;
      int mStep=0;
  };
}
