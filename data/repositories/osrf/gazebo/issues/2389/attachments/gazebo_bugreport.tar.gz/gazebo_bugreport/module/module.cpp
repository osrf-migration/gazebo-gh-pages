#include "module.h"
#include <boost/bind.hpp>
#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <stdio.h>

namespace gazebo {
  void POCModule::Load(physics::ModelPtr _parent, sdf::ElementPtr /*_sdf*/) {
    GOOGLE_PROTOBUF_VERIFY_VERSION;
    std::cout<<"Module loaded"<<std::endl;

    this->mWorld = _parent->GetWorld();

    physics::WorldState ws(mWorld);
    //Workaround
    ws.GetModelState("minimal").GetLinkState("link").SetRecordVelocity(true);

    this->updateConnection = event::Events::ConnectWorldUpdateBegin(
                               boost::bind(&POCModule::OnUpdate, this, _1));
  }

  void POCModule::OnUpdate(const common::UpdateInfo & /*_info*/) {
    if (mStep%1000==0) {
      physics::WorldState ws(mWorld);
      std::cout<<"State restored to "<<ws<<std::endl;
      mWorld->SetState(ws);
    }
    ++mStep;
  }

  GZ_REGISTER_MODEL_PLUGIN(POCModule)
}

// vim: autoindent expandtab tabstop=2 shiftwidth=2
