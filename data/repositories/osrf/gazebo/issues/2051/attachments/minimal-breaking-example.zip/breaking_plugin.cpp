#include <gazebo/gazebo.hh>
#include <gazebo/physics/physics.hh>
#include <gazebo/common/common.hh>
#include <gazebo/transport/transport.hh>

using namespace gazebo;

class LightControl : public WorldPlugin
{
public:
  LightControl(){};
  ~LightControl(){};

  virtual void Load(physics::WorldPtr _world, sdf::ElementPtr _sdf)
  {
    world_ = _world;
    update_connection_ = event::Events::ConnectWorldUpdateBegin(boost::bind(&LightControl::OnUpdate, this, _1));
    node_ = transport::NodePtr(new transport::Node());
    node_->Init(world_->GetName());
    visPub_ = this->node_->Advertise<msgs::Visual>("~/visual", /*max number of lights*/ 3*12);
    last_sent_time_ = world_->GetSimTime().Double();
  }
  
  virtual void OnUpdate(const common::UpdateInfo &)
  {
    double time = world_->GetSimTime().Double();    
    if(time - last_sent_time_ < 0.1)
      return;
    last_sent_time_ = time;

    state_on = !state_on;

    msgs::Visual msg;
    
    //////////// this line costs ~20 FPS in Gazbeo 7
    msg.set_transparency(0.0);
    ///////////
    
    msgs::Geometry *geomMsg = msg.mutable_geometry();
    geomMsg->set_type(msgs::Geometry::CYLINDER);
    geomMsg->mutable_cylinder()->set_radius(0.05);
    geomMsg->mutable_cylinder()->set_length(0.1);
    msg.set_cast_shadows(false);
    msg.set_parent_name("light::link");
    msg.set_name("light::link::redon");
#if GAZEBO_MAJOR_VERSION > 5
    msgs::Set(msg.mutable_pose(), ignition::math::Pose3d(1, 0, 0.085, 0, 0, 0));
#else
    msgs::Set(msg.mutable_pose(), math::Pose(1, 0, 0.085, 0, 0, 0));
#endif
    msgs::Set(msg.mutable_material()->mutable_diffuse(), common::Color(0.8, 0, 0, 0.8));
    msgs::Set(msg.mutable_material()->mutable_emissive(), common::Color(1.0, 0.3, 0.3, 1.0));
    if(state_on)
      msg.set_visible(true);
    else
      msg.set_visible(false);
    visPub_->Publish(msg);
  }

private:
  physics::WorldPtr world_;
  event::ConnectionPtr update_connection_;
  transport::NodePtr node_;
  transport::PublisherPtr visPub_;
  double last_sent_time_;
  bool state_on = true;
};

GZ_REGISTER_WORLD_PLUGIN(LightControl)
