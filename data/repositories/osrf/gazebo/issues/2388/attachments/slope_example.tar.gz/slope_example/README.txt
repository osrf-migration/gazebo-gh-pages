To run this example:

1) Your Gazebo model path needs to point to this folder OR you need to move the elevation_models and slope_terrain folders to your Gazebo model path directory.

2) Run the world file in Gazebo preferably starting in paused mode. To achieve this, either "gazebo -u slope_example.world" OR "rosrun gazebo_ros gazebo -u slope_example.world"

3) Unpause and see what happens

It is also okay to modify the .world file to adjust the sizes and positions of the spheres.
